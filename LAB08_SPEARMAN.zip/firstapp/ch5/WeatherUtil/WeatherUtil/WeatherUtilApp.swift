//
//  WeatherUtilApp.swift
//  WeatherUtil
//
// Created by Amara Spearman on 10/27/23.
//

import SwiftUI

@main
struct WeatherUtilApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
